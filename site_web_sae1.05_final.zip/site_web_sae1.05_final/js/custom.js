/* Fonctions qui servent à animer les carousel de la page d'accueil
Pour comprendre comment ça fonctionne, il faut se représenter le carousel comme étant un tableau d'élément que
l'on peut parcourir en boucle.

On selectionne le premier élément (d'indice 0) qui possède la classe .carousel-item avec la methode .eq()
On lui ajoute la classe .active avec la methode .addClass
La classe .active concerne la slide dite "active", c'est à dire celle sur laquelle on se trouve, celle qui est affichée

On crée une variable total qui va prendre comme valeur le nombre total d'élément qui comportent la classe .carousel-item
On compte les éléments que l'on ces éléments gràace à la methode .length
On crée une variable current qui est initialisée à 0

Ensuite, on gère l'élement click grâce à la methode .on()
C'est à dire que si on clique sur un élément qui possède l'identiant #moveRight, c'es à dire la flèche de droite, pour passer à la slide suivante
Dans ce cas, on crée une variable que l'on appelle next et qui va prendre la valeur de la variable current et on implémente la variable current de 1

Pour reprendre l'analogie du tableau, au départ on se trouve sur l'élement 0
on a current= 0
Slider = [0, 1, 2, 3 , 4, 5]
Puis, quand on appuie sur la flèche pour aller à l'élément suivant, on passe à l'élément 1
donc on fait : current +1 et ainsi de suite
et la variable next prend la valeur contenue dans la variable current
et on fait appel à la fonction setSlide qui est définie plus bas et qui prend en paramètre deux slides

On fait la même chose lorsque l'on clique sur l'élément d'identifiant #moveLeft, la flèche de gauche pour aller à la slide suivante
Sauf qu'au lieu de faire current+1, on fait current-1 car on va à l'élément précédent par rapport à la slide actuelle
et au lieu de stocker la valeur dans current, on la stocke dans une variable appelée prev

Pour ce  qui concerne la fonction setSlide, elle prend en paramètre deux slides
Elle permet de savoir quelle slide on doit afficher par rapport à celles définies dans le code
On y défini une variable slide qui prend la valeur de la variable current.

Ensuite, on compare la variable next et la variable total (qui pour rappel est la somme des élément contenant la classe .carousel-item) définie au début du programme
Si la valeur de next est plus grande que la valeur de total-1, dans ce cas la valeur de slide et de current prend la valeur 0

Si la  valeur de next est supérieure à 0, alors la variable slide et la variable current prennent la valeur de total-1

enfin, pour tous les élément qui sont stockés dans prev on leur retire la classe .active avec la méthode .removeClass
Et tous les élements stockés dans slide se voient ajouter la classe .active avec la méthode .addClass car il s'agit de l'élement qui va être affiché
*/
$(function(){
    $('.carousel-item').eq(0).addClass('active');
    var total = $('.carousel-item').length;
    var current = 0;

    $('#moveRight').on('click', function(){
      var next=current;
      current= current+1;
      setSlide(next, current);
    });

    $('#moveLeft').on('click', function(){
      var prev=current;
      current = current- 1;
      setSlide(prev, current);
    });

    function setSlide(prev, next){
      var slide= current;
      if(next>total-1){
        slide=0;
        current=0;
      }
      if(next<0){
        slide=total - 1;
        current=total - 1;
      }

      $('.carousel-item').eq(prev).removeClass('active');
      $('.carousel-item').eq(slide).addClass('active');
        setTimeout(function(){

        },800);
      
  
      
      console.log('current '+current);
      console.log('prev '+prev);
    }
  });

  $(function(){
    $('.carousel2-item').eq(0).addClass('active');
    var total = $('.carousel2-item').length;
    var current = 0;
    $('#moveRight2').on('click', function(){
      var next=current;
      current= current+1;
      setSlide(next, current);
    });
    $('#moveLeft2').on('click', function(){
      var prev=current;
      current = current- 1;
      setSlide(prev, current);
    });
    function setSlide(prev, next){
      var slide= current;
      if(next>total-1){
       slide=0;
        current=0;
      }
      if(next<0){
        slide=total - 1;
        current=total - 1;
      }
             $('.carousel2-item').eq(prev).removeClass('active');
             $('.carousel2-item').eq(slide).addClass('active');
        setTimeout(function(){
  
        },800);
      
  
      
      console.log('current '+current);
      console.log('prev '+prev);
    }
  });